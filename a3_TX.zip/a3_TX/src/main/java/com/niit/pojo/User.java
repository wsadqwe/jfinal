package com.niit.pojo;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class User {

    private int id;
    private String usernmame;
    private int money;
}
