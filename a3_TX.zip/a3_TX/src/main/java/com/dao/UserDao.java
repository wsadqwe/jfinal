package com.dao;

public interface UserDao {
    public void reduceMoney();

    public void addMoney();
}
