import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import service.UserService;

import javax.management.InvalidApplicationException;

public class UserTest {

    @Test
    public void test1(){
        ApplicationContext context=
                new ClassPathXmlApplicationContext("bean1.xml");
        UserService service=context.getBean(UserService.class);
        service.accountMoney();
    }
}
